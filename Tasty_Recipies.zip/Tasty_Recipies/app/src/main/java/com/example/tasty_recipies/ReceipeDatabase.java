package com.example.tasty_recipies;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(version = 1,entities = {Receipes.class})
public abstract class ReceipeDatabase extends RoomDatabase {
    public abstract RecipeDao getDao();
}



