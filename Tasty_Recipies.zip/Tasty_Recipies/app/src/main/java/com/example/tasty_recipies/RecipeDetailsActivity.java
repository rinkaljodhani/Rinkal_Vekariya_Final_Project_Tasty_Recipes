package com.example.tasty_recipies;

import static android.widget.FrameLayout.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class RecipeDetailsActivity extends AppCompatActivity implements View.OnClickListener,DBManager.DataBaseListener {

    Receipes receipes;
    TextView tv_des,tv_save;
    VideoView video_view;
    FrameLayout fflayout;
    boolean flag = false;
    boolean flag1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        findView();


    }

    private void findView() {

        receipes = (Receipes) getIntent().getSerializableExtra("response");
        flag1 = getIntent().getBooleanExtra("flag",false);



        getSupportActionBar().setTitle(receipes.name);

        tv_des = findViewById(R.id.tv_des);
        tv_save = findViewById(R.id.tv_save);
        video_view = findViewById(R.id.video_view);
        fflayout = findViewById(R.id.fflayout);
        Uri uri = Uri.parse(receipes.video_url);
        video_view.setVideoURI(uri);
        if(flag1){
            tv_save.setVisibility(GONE);
        }else{
            tv_save.setVisibility(VISIBLE);
        }
        MediaController mediaController = new MediaController(this);

        video_view.setMediaController(mediaController);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM;
        mediaController.setLayoutParams(lp);

        ((ViewGroup) mediaController.getParent()).removeView(mediaController);

        fflayout.addView(mediaController);
        flag = true;
// initiate a video view
// set media controller object for a video view

        video_view.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(flag){
                    fflayout.removeAllViews();
                    flag = false;
                }else{
                    fflayout.removeAllViews();
                    fflayout.addView(mediaController);
                    flag = true;
                }
                return false;
            }
        });

        tv_des.setText(receipes.des);
        tv_save.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_save:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Are you sure you want to save "+ receipes.name+" to the DB??");
                builder.setNegativeButton("No",null);
                builder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        ((MyApp)getApplication()).dbManager.insertNewCityAsync(receipes);
                    }
                });
                builder.create().show();
                break;
        }
    }


    @Override
    public void insertingRecipeCompleted() {
        Toast.makeText(RecipeDetailsActivity.this,"Recipe is successfully added to Favourite list",Toast.LENGTH_LONG).show();

    }

    @Override
    public void gettingRecipesCompleted(Receipes[] list) {

    }

    @Override
    public void alreadyinsertingRecipeCompleted() {
        Log.e("alreadyinserting::","ttt" );
        Toast.makeText(RecipeDetailsActivity.this,"Already added",Toast.LENGTH_LONG).show();

    }
}