package com.example.tasty_recipies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkingService.NetworkingListener, View.OnClickListener,DBManager.DataBaseListener {


    RecyclerView rv_list;
    RecipiesListAdapter adapter;
    ArrayList<Receipes> list = new ArrayList<>(0);
    ProgressDialog progressDialog;
    TextView tv_favlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((MyApp) getApplication()).networkingService.listener = this;

        findView();
        ((MyApp) getApplication()).networkingService.getRecipieDetails();


    }

    private void findView() {

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Please wait");
        progressDialog.show();
        rv_list = findViewById(R.id.rv_list);
        tv_favlist = findViewById(R.id.tv_favlist);
        adapter = new RecipiesListAdapter(this,list,false);
        rv_list.setAdapter(adapter);
        rv_list.setLayoutManager(new LinearLayoutManager(this));
        ((MyApp) getApplication()).dbManager.listener = this;

        ((MyApp)getApplication()).dbManager.getDB(this);
        tv_favlist.setOnClickListener(this);
    }

    @Override
    public void gettingJsonIsCompleted(String json) {
        progressDialog.dismiss();
        list = JsonService.fromJSONToList(json);
        adapter.list = list;
        adapter.notifyDataSetChanged();
    }

    @Override
    public void gettingImageIsCompleted(Bitmap image) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.tv_favlist:
                startActivity(new Intent(MainActivity.this,FavouriteActivity.class));
            break;
        }
    }

    @Override
    public void insertingRecipeCompleted() {
        Toast.makeText(MainActivity.this,"Recipe is successfully added to Favourite list",Toast.LENGTH_LONG).show();

    }

    @Override
    public void gettingRecipesCompleted(Receipes[] list) {

    }
    @Override
    public void alreadyinsertingRecipeCompleted() {
        Toast.makeText(MainActivity.this,"Already added",Toast.LENGTH_LONG).show();

    }
}