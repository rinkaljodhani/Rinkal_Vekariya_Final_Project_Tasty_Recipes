package com.example.tasty_recipies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class FavouriteActivity extends AppCompatActivity implements DBManager.DataBaseListener{

    TextView tv_nodata;
    RecipiesListAdapter adapter;
    RecyclerView rv_list;
    ArrayList<Receipes> recipe_list = new ArrayList<>(0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        this.setTitle("Fav Recipes");
        findView();
    }

    private void findView() {
        rv_list = findViewById(R.id.rv_list);
        tv_nodata = findViewById(R.id.tv_nodata);

        adapter = new RecipiesListAdapter(this,recipe_list,true);
        rv_list.setAdapter(adapter);
        rv_list.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        ((MyApp) getApplication()).dbManager.getDB(this);
        ((MyApp) getApplication()).dbManager.getAllReceipes();
        ((MyApp) getApplication()).dbManager.listener = this;
    }


    @Override
    public void insertingRecipeCompleted() {
        Toast.makeText(FavouriteActivity.this,"Recipe is successfully added to Favourite list",Toast.LENGTH_LONG).show();

    }

    @Override
    public void alreadyinsertingRecipeCompleted() {
        Log.e("alreadyinserting::","ttt" );
        Toast.makeText(FavouriteActivity.this,"Already added",Toast.LENGTH_LONG).show();

    }

    @Override
    public void gettingRecipesCompleted(Receipes[] list) {
        recipe_list = new ArrayList( Arrays.asList(list));
        if(recipe_list.size() == 0){
            tv_nodata.setVisibility(View.VISIBLE);
            rv_list.setVisibility(View.GONE);
        }else{
            tv_nodata.setVisibility(View.GONE);
            rv_list.setVisibility(View.VISIBLE);
        }
        adapter.list = recipe_list;
        adapter.notifyDataSetChanged();
    }
}