package com.example.tasty_recipies;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonService {

    static ArrayList<Receipes> fromJSONToList(String jsonString){
        ArrayList<Receipes> list = new ArrayList<>(0);
        try {

            JSONObject jsonObject = new JSONObject(jsonString);

            JSONArray jsonArray = jsonObject.getJSONArray("results");

            for (int i = 0 ; i< jsonArray.length(); i++){
               Log.d("weathee_app", jsonArray.getString(i));
               String name = jsonArray.getJSONObject(i).getString("name");
               String des = jsonArray.getJSONObject(i).getString("description");
               String thumbnail_url = jsonArray.getJSONObject(i).getString("thumbnail_url");
               String video_url = jsonArray.getJSONObject(i).getString("video_url");
                list.add(new Receipes(name,des,thumbnail_url,video_url));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

}
